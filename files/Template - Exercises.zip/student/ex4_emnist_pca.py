#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exercise 5: Distributed learning on EMNIST (digits 3 vs 8).
Images are projected onto the top-k PCA components so that each agent's
feature matrix is full rank.
"""

import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from sklearn.decomposition import PCA
from torchvision import datasets, transforms

# ------ problem data
n         = 10    # agents
N         = 100   # training samples per agent
k_pca     = 50    # PCA components (< N  =>  each M_i is full rank)
simu_time = 10000

# ------ (a) load EMNIST: digits 3 (label -1) and 8 (label +1)
train_set = datasets.EMNIST(
    root='../data', split='digits', train=True, download=False,
    transform=transforms.ToTensor(),
)
mask   = (train_set.targets == 3) | (train_set.targets == 8)
images = train_set.data[mask]                           # (N_tot, 28, 28) uint8
labels = np.sign(train_set.targets[mask].numpy() - 5)  # -1 for digit 3, +1 for digit 8

# ------ (b) PCA: fit on the n*N training images, project to k_pca dimensions
#   Flatten and normalise each image to [0,1]^784, stack into raw (n*N, 784).
#   Why does k_pca < N guarantee that M_i = X_i^T X_i / N is positive definite?
raw = np.vstack([
    images[i].numpy().T.reshape(28 * 28).astype(float) / 255.0
    for i in range(n * N)
])                                       # (n*N, 784)

# TODO (b): fit PCA with k_pca components on raw and transform raw to X_train
pca     = None   # replace with PCA(n_components=k_pca).fit(raw)
X_train = None   # replace with pca.transform(raw)  -- shape (n*N, k_pca)
m       = k_pca  # feature dimension is now k_pca

# ------ (c) build local quadratic costs  f_i(w) = 1/(2N) ||X_i w - y_i||^2
#   M_i = X_i^T X_i / N   (positive definite since k_pca < N)
#   q_i = -X_i^T y_i / N
Ms, qs  = [], []
max_eig = 0.0
for i in range(n):
    X = X_train[i*N : (i+1)*N]               # (N, k_pca)
    y = labels[i*N : i*N + N].reshape(-1, 1) # (N, 1)
    # TODO (c): compute Mi = X^T X / N and qi = -X^T y / N
    Mi = None
    qi = None
    ei = np.linalg.eigvalsh(Mi)[-1]
    Ms.append(Mi)
    qs.append(qi)
    max_eig = max(max_eig, ei)
    print(f"  agent {i}  lambda_max = {ei:.4f}  "
          f"lambda_min = {np.linalg.eigvalsh(Mi)[0]:.6f}")

x_opt = -np.linalg.inv(sum(Ms)) @ sum(qs)   # centralized optimum (benchmark)

# ------ (d) network and weight matrix W = I - eps*L
G      = nx.erdos_renyi_graph(n, 0.8, seed=42)
A      = nx.adjacency_matrix(G).toarray()
Lg     = nx.laplacian_matrix(G).toarray().astype(float)
vareps = 0.1
W      = np.eye(n) - vareps * Lg

# ------ (d) step size: rho = 0.9*(1-sigma)^2 / L,  sigma = second largest eigenvalue of W
eigs_W = np.linalg.eigvalsh(W)
sigma  = eigs_W[-2]
step   = 0.9 * (1 - sigma)**2 / max_eig
print(f"L = {max_eig:.4f},  sigma = {sigma:.4f},  step = {step:.6f}")

# ------ gradient helper: grad f_i(w) = M_i w + q_i
def gradf(i, w):
    return Ms[i] @ w + qs[i]

# ------ ADMM precomputation
d_deg     = A.sum(axis=1).astype(float)
rho_admm  = 1.0
alpha_adm = 0.5
prox_mats = [np.linalg.inv(Ms[i] + rho_admm * d_deg[i] * np.eye(m)) for i in range(n)]

# ---------------------------------------------------------------
# (e) Gradient step tracking
# y_i(t+1) = x_i(t) - rho * grad_fi(x_i(t)),   y_i(0) = x_i(0) = 0
# x_i(t+1) = sum_j W_ij x_j(t) + (y_i(t+1) - y_i(t))
# ---------------------------------------------------------------
x_gst = [np.zeros((m, 1)) for _ in range(n)]
y_gst = [np.zeros((m, 1)) for _ in range(n)]   # y_i(0) = x_i(0) = 0

errors_gst = []
for t in range(simu_time):
    # TODO (e): compute y_new[i] = x_gst[i] - step * grad
    y_new = None  # list of n vectors

    x_new = []
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (e): x_i(t+1) = consensus step + (y_new[i] - y_gst[i])
        x_new.append(None)

    errors_gst.append(max(np.linalg.norm(x_new[i] - x_opt) for i in range(n)))
    y_gst = y_new
    x_gst = x_new
    if (t + 1) % 1000 == 0:
        print(f"  GT     {t+1}/{simu_time}")

print("Done: gradient step tracking")

# ---------------------------------------------------------------
# (f) gradient tracking
# y_i(0) = grad_fi(x_i(0))
# x_i(t+1) = sum_j W_ij x_j(t) - rho * y_i(t)
# y_i(t+1) = sum_j W_ij y_j(t) + grad_fi(x_i(t+1)) - grad_fi(x_i(t))
# NOTE: compute all x_i(t+1) before updating any y_i(t+1)
# ---------------------------------------------------------------
x_gt = [np.zeros((m, 1)) for _ in range(n)]
y_gt = [gradf(i, x_gt[i]) for i in range(n)]

errors_gt = []
for t in range(simu_time):
    x_new = []
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (f): x_i(t+1) = consensus step - step * y_gt[i]
        x_new.append(None)
    y_new = []
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (f): y_i(t+1) = consensus of y + gradient correction
        y_new.append(None)
    errors_gt.append(max(np.linalg.norm(x_new[i] - x_opt) for i in range(n)))
    x_gt = x_new
    y_gt = y_new
    if (t + 1) % 1000 == 0:
        print(f"  gradient tracking {t+1}/{simu_time}")

print("Done: gradient tracking")

# ---------------------------------------------------------------
# Distributed ADMM  (optional extension)
# x_i(t+1) = (M_i + rho*d_i*I)^{-1} * (sum_j z[i][j](t) - q_i)
# z[i][j](t+1) = (1-alpha)*z[i][j](t) + alpha*(2*rho*x_j(t+1) - z[j][i](t))
# ---------------------------------------------------------------
z      = {i: {j: np.zeros((m, 1)) for j in np.nonzero(A[i, :])[0]} for i in range(n)}
x_admm = [np.zeros((m, 1)) for _ in range(n)]

errors_admm = []
for t in range(simu_time):
    x_new = []
    for i in range(n):
        nb    = np.nonzero(A[i, :])[0]
        z_sum = sum(z[i][j] for j in nb)
        # TODO: x_i(t+1) = proximal step
        x_new.append(None)
    z_new = {i: {} for i in range(n)}
    for i in range(n):
        for j in np.nonzero(A[i, :])[0]:
            # TODO: z[i][j](t+1) = dual variable update
            z_new[i][j] = None
    errors_admm.append(max(np.linalg.norm(x_new[i] - x_opt) for i in range(n)))
    x_admm = x_new
    z      = z_new
    if (t + 1) % 1000 == 0:
        print(f"  ADMM   {t+1}/{simu_time}")

print("Done: ADMM")

# ------ convergence plot
plt.rc("text", usetex=True)
plt.rc("font", family="serif")
fontsize = 18
time_ax  = np.arange(simu_time)
plt.figure()
plt.semilogy(time_ax, errors_gst,   label="gradient step tracking (e)")
plt.semilogy(time_ax, errors_gt,  label="gradient tracking (f)")
plt.semilogy(time_ax, errors_admm, label="ADMM")
plt.legend(fontsize=fontsize - 3)
plt.xlabel("Iteration $t$", fontsize=fontsize)
plt.ylabel(r"$\max_i\,\|w_i(t)-w^\star\|$", fontsize=fontsize)
plt.grid()
plt.tight_layout()
plt.show()

# ------ (g) test accuracy (apply the same PCA transform to test images)
test_set  = datasets.EMNIST(
    root='../data', split='digits', train=False, download=False,
    transform=transforms.ToTensor(),
)
mask_test  = (test_set.targets == 3) | (test_set.targets == 8)
imgs_test  = test_set.data[mask_test]
lbls_test  = test_set.targets[mask_test]
X_test_raw = np.vstack([
    imgs_test[i].numpy().T.reshape(28 * 28).astype(float) / 255.0
    for i in range(len(imgs_test))
])
# TODO (g): project X_test_raw onto the PCA components using pca.transform
X_test = None   # replace with pca.transform(X_test_raw)

def accuracy(w_vec):
    preds    = (X_test @ w_vec >= 0).astype(int)
    true_lbl = (lbls_test.numpy() == 8).astype(int)
    return (preds == true_lbl).mean()

w_gt   = np.mean([x_gst[i].reshape(-1)   for i in range(n)], axis=0)
w_dig  = np.mean([x_gt[i].reshape(-1)  for i in range(n)], axis=0)
w_admm = np.mean([x_admm[i].reshape(-1) for i in range(n)], axis=0)

print(f"Test accuracy  gradient step tracking: {accuracy(w_gt):.3f}")
print(f"Test accuracy  gradient tracking:                 {accuracy(w_gt):.3f}")
print(f"Test accuracy  ADMM:                   {accuracy(w_admm):.3f}")
