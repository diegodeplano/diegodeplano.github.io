#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Load a saved linear classifier and evaluate it on EMNIST digits 3 vs 8.

Set MODEL_PATH to the .npy file produced by the training scripts:
    "model_centralized.npy"    (from lecture_test_centralized_emnist.py)
    "model_distributed.npy"    (from lecture_test_distributed_emnist.py  -- ADMM)
    "model_distributed.npy"    (from ex4_emnist_pca.py                   -- ADMM + PCA)

If a companion "model_distributed_bias.npy" exists (produced by ex4_emnist_pca.py),
it is loaded and used as the decision threshold to correct for PCA mean-centering.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from torchvision import datasets, transforms

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
MODEL_PATH = "model_distributed.npy"   # <-- change to switch model
N_SHOW     = 16                         # images displayed in the grid
SEED       = np.random.randint(0, 10000)

# ---------------------------------------------------------------------------
# Load model (and optional bias from PCA mean-centering correction)
# ---------------------------------------------------------------------------
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(
        f"Model file '{MODEL_PATH}' not found. "
        "Run ex4_emnist_pca.py first to generate it."
    )
w = np.load(MODEL_PATH).reshape(-1)    # (784,) weight vector
print(f"Loaded: {MODEL_PATH}  weights shape: {w.shape}")

bias_path = MODEL_PATH.replace(".npy", "_bias.npy")
if os.path.exists(bias_path):
    bias = float(np.load(bias_path))
    print(f"Loaded bias correction: {bias:.4f}  (from {bias_path})")
else:
    bias = 0.0

# ---------------------------------------------------------------------------
# Load EMNIST test data (digits 3 and 8 only, raw pixels)
# ---------------------------------------------------------------------------
test_set = datasets.EMNIST(
    root="../data", split="digits", train=False, download=False,
    transform=transforms.ToTensor(),
)

mask   = (test_set.targets == 3) | (test_set.targets == 8)
images = test_set.data[mask]     # (N, 28, 28)  uint8 tensor
labels = test_set.targets[mask]  # (N,)         int   tensor

# ---------------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------------
def predict(img):
    """img: (28, 28) uint8 numpy array.  Returns predicted digit: 3 or 8."""
    feat = img.T.reshape(-1).astype(float) / 255.0
    return 8 if np.dot(feat, w) >= bias else 3

# ---------------------------------------------------------------------------
# Visualize a random sample with colour-coded results
# ---------------------------------------------------------------------------
rng     = np.random.default_rng(SEED)
indices = rng.choice(len(images), size=N_SHOW, replace=False)

cols, rows = 4, N_SHOW // 4
fig, axes  = plt.subplots(rows, cols, figsize=(cols * 2, rows * 2.5))
fig.suptitle(f"EMNIST 3 vs 8 - {MODEL_PATH}", fontsize=11)

for ax, idx in zip(axes.flat, indices):
    img        = images[idx].numpy()
    true_label = int(labels[idx])
    pred_label = predict(img)
    correct    = pred_label == true_label

    ax.imshow(img.T, cmap="gray")
    ax.set_title(
        f"true {true_label}  pred {pred_label}",
        color="green" if correct else "red",
        fontsize=9,
    )
    ax.axis("off")

plt.tight_layout()
plt.show()

# ---------------------------------------------------------------------------
# Overall test-set accuracy
# ---------------------------------------------------------------------------
n_correct = sum(
    predict(images[i].numpy()) == int(labels[i])
    for i in range(len(images))
)
print(f"Test accuracy on 3 vs 8: {n_correct}/{len(images)} = {n_correct / len(images):.3f}")
