#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exercise 3: Compare simple averaging (d), gradient step tracking (e), gradient tracking (f), and ADMM (g).
All algorithms must be implemented explicitly following the distributed update rules.
"""

import numpy as np
from numpy.random import default_rng
import matplotlib.pyplot as plt
import networkx as nx

ran = default_rng(0)

# ------ problem data
n         = 10   # number of agents
m         = 2    # variable dimension
simu_time = 1000

# ------ network and weight matrix W = I - eps*L
G      = nx.erdos_renyi_graph(n, 0.8, seed=42)
A      = nx.adjacency_matrix(G).toarray()
Lg     = nx.laplacian_matrix(G).toarray().astype(float)
vareps = 0.1
W      = np.eye(n) - vareps * Lg

# ------ local cost functions: f_i(x) = 1/2 x^T M_i x + q_i^T x
min_eig, max_eig = 3, 7
Ms    = [ran.standard_normal((m, m)) for _ in range(n)]
Ms    = [Q @ np.diag(ran.uniform(min_eig, max_eig, m)) @ Q.T
         for Q in [np.linalg.qr(M)[0] for M in Ms]]
qs    = [ran.normal(scale=10, size=(m, 1)) for _ in range(n)]
x_opt = -np.linalg.inv(sum(Ms)) @ sum(qs)

# ------ step size: rho < (1-sigma)^2 / L
#   sigma = second largest eigenvalue of W  (spectral gap on 1_perp)
eigs_W = np.linalg.eigvalsh(W)
sigma  = eigs_W[-2]
step   = 0.9 * (1 - sigma)**2 / max_eig
print(f"L = {max_eig:.4f},  sigma = {sigma:.4f},  step = {step:.6f}")

# ------ gradient helper: grad f_i(x) = M_i x + q_i
def gradf(i, x):
    return Ms[i] @ x + qs[i]

# ------ initialization: each agent starts at its own local optimum
x_0s = [-np.linalg.inv(Ms[i]) @ qs[i] for i in range(n)]

# ---------------------------------------------------------------
# (d) Simple (static) average consensus
# y_i(k)   = x_i(k) - rho * grad_fi(x_i(k))        [local GD step]
# x_i(k+1) = sum_{j in Ni U{i}} W_ij * y_j(k)      [static averaging]
# ---------------------------------------------------------------
x_simple = [[x_0s[i].copy()] for i in range(n)]
y_simple = [[] for _ in range(n)]

for k in range(simu_time):
    for i in range(n):
        # TODO (d): compute y_i(k) = local GD step at x_i(k)
        pass
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (d): compute x_i(k+1) = weighted average of y_j(k) over neighbors
        pass
    if (k + 1) % 100 == 0:
        print(f"  {k + 1}/{simu_time}")

print("Done: simple averaging")

# ---------------------------------------------------------------
# (e) Gradient step tracking -- DAC on full GD step
# y_i(k)   = x_i(k) - rho * grad_fi(x_i(k))
# x_i(k+1) = sum_{j in Ni U{i}} W_ij * x_j(k) + y_i(k) - y_i(k-1)
# Initialize: y_i(0) = x_i(0) = 0
# ---------------------------------------------------------------
x_gst = [[x_0s[i].copy()] for i in range(n)]
y_gst = [[] for _ in range(n)]

for k in range(simu_time):
    for i in range(n):
        # TODO (e): compute y_i(k) = local GD step at x_i(k)
        pass
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (e): compute x_i(k+1) using the consensus update + correction term
        #           Note: y_i(-1) = y_i(0) (so the correction is 0 at k=0)
        pass
    if (k + 1) % 100 == 0:
        print(f"  {k + 1}/{simu_time}")

print("Done: gradient step tracking")

# ---------------------------------------------------------------
# (f) gradient tracking -- DAC on partial iterate (gradient)  (Nedic et al. 2017)
# Initialize: y_i(0) = grad_fi(x_i(0))
# x_i(k+1) = sum_{j in Ni U{i}} W_ij * x_j(k) - rho * y_i(k)
# y_i(k+1) = sum_{j in Ni U{i}} W_ij * y_j(k) + grad_fi(x_i(k+1)) - grad_fi(x_i(k))
# NOTE: compute all x_i(k+1) before updating any y_i(k+1)
# ---------------------------------------------------------------
x_gt = [[x_0s[i].copy()] for i in range(n)]
y_gt = [[gradf(i, x_0s[i])] for i in range(n)]

for k in range(simu_time):
    # step 1: compute all x_i(k+1)
    x_new = []
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (f): x_i(k+1) = consensus step - rho * y_i(k)
        pass
    # step 2: compute all y_i(k+1) using the updated x
    y_new = []
    for i in range(n):
        nb = np.hstack([i, np.nonzero(A[i, :])[0]])
        # TODO (f): y_i(k+1) = consensus of y + gradient correction
        pass
    for i in range(n):
        x_gt[i].append(x_new[i])
        y_gt[i].append(y_new[i])
    if (k + 1) % 100 == 0:
        print(f"  {k + 1}/{simu_time}")

print("Done: gradient tracking")

# ---------------------------------------------------------------
# (g) Distributed ADMM
# x_i(k+1) = (M_i + rho*d_i*I)^{-1} * (sum_j z[i][j](k) - q_i)
# z[i][j](k+1) = (1-alpha)*z[i][j](k) + alpha*(2*rho*x_j(k+1) - z[j][i](k))
# Initialize: z[i][j] = 0
# ---------------------------------------------------------------
rho_admm   = 1.0
alpha_admm = 0.5
d_deg      = A.sum(axis=1).astype(float)
prox_mats  = [np.linalg.inv(Ms[i] + rho_admm * d_deg[i] * np.eye(m)) for i in range(n)]

z      = {i: {j: np.zeros((m, 1)) for j in np.nonzero(A[i, :])[0]} for i in range(n)}
x_admm = [[x_0s[i].copy()] for i in range(n)]

for k in range(simu_time):
    x_new = []
    for i in range(n):
        nb = np.nonzero(A[i, :])[0]
        # TODO (g): x_i(k+1) = proximal step using precomputed prox_mats[i]
        pass
    z_new = {i: {} for i in range(n)}
    for i in range(n):
        for j in np.nonzero(A[i, :])[0]:
            # TODO (g): z[i][j](k+1) = dual variable update
            pass
    for i in range(n):
        x_admm[i].append(x_new[i])
    z = z_new
    if (k + 1) % 100 == 0:
        print(f"  {k + 1}/{simu_time}")

print("Done: ADMM")

# ------ (h) error: max agent distance to optimal
def max_error(x_traj):
    return [max(np.linalg.norm(x_traj[i][k] - x_opt) for i in range(n))
            for k in range(simu_time)]

errors_simple = max_error(x_simple)
errors_gst     = max_error(x_gst)
errors_gt    = max_error(x_gt)
errors_admm   = max_error(x_admm)

# ------ comparing plot
plt.rc("text", usetex=True)
plt.rc("font", family="serif")
fontsize = 18
time = np.arange(0, simu_time)
plt.figure()
plt.semilogy(time, errors_simple, label="Simple averaging (d)")
plt.semilogy(time, errors_gst,     label="Gradient step tracking (e)")
plt.semilogy(time, errors_gt,    label="gradient tracking (f)")
plt.semilogy(time, errors_admm,   label="ADMM (g)")
plt.legend(fontsize=fontsize - 3)
plt.xlabel("Iteration $k$", fontsize=fontsize)
plt.ylabel(r"$\max_i\,\|x_i(k)-x^\star\|$", fontsize=fontsize)
plt.grid()
plt.tight_layout()
plt.show()
