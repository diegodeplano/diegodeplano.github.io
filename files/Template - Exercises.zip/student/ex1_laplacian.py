#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exercise 1 - Part II: Gradient descent on a Laplacian quadratic objective.
Compares convergence for rho ~ 1/d_max (standard) vs rho ~ 2/lambda_max(Lg) (spectral).
"""

import numpy as np
from numpy.random import default_rng
import matplotlib.pyplot as plt
import networkx as nx

ran = default_rng()

# ------ problem data
n         = 10
simu_time = 1000
x_0       = 10 * ran.standard_normal((n, 1))

# ------ cost function: f(x) = 1/2 x^T Lg x,  grad f(x) = Lg x
#   (g) write the update rule in compact form
#   (h) write the i-th component update; can it be computed distributedly?
#   (i) compute the set of minimizers
#   (j) determine L = lambda_max(Lg) and the step-size condition
#   (k) compare the spectral bound rho < 2/lambda_max(Lg) with the degree bound rho < 1/d_max
G        = nx.erdos_renyi_graph(n, 0.8, seed=42)
Lg       = nx.laplacian_matrix(G).toarray().astype(float)
eigs     = np.linalg.eigvalsh(Lg)
max_eig  = eigs[-1]
maxdeg   = np.max(np.array(G.degree())[:, 1])
x_opt    = np.mean(x_0) * np.ones((n, 1))   # consensus value = initial mean

# ------ step sizes: standard degree bound vs spectral bound
steps  = [0.1 / maxdeg, 0.99 / maxdeg, 0.99 * 2 / max_eig]
labels = [rf"$\rho = 0.1/d_{{\max}}$               (={steps[0]:.3f})",
          rf"$\rho \approx 1/d_{{\max}}$            (={steps[1]:.3f})",
          rf"$\rho \approx 2/\lambda_{{\max}}(L)$ (={steps[2]:.3f})"]

# ------ (f) run GD for each step size:  x(k+1) = x(k) - rho * Lg x(k)
results = []
for step, label in zip(steps, labels):
    x = [x_0]
    for k in range(simu_time):
        # TODO (f): implement one GD step and append the new iterate to x
        pass
    results.append(x)
    print(f"Done: {label}")

# ------ comparing plot
plt.rc("text", usetex=True)
plt.rc("font", family="serif")
fontsize = 18
time = np.arange(0, simu_time, 1)
plt.figure()
for x, label in zip(results, labels):
    plt.semilogy(time, [np.linalg.norm(x[k] - x_opt) for k in range(simu_time)], label=label)
plt.legend(fontsize=fontsize - 3)
plt.xlabel("Iteration $k$", fontsize=fontsize)
plt.ylabel(r"$\|x(k) - x^\star\|$", fontsize=fontsize)
plt.grid()
plt.tight_layout()
plt.show()
