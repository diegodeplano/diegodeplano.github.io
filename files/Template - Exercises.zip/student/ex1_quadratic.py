#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exercise 1 - Part I: Gradient descent on a general quadratic objective.
Compares convergence for rho = 0.1/L, 1/L, 3/L.
"""

import numpy as np
from numpy.random import default_rng
import matplotlib.pyplot as plt

ran = default_rng()

# ------ problem data
n         = 10
simu_time = 1000
x_0       = 10 * ran.standard_normal((n, 1))

# ------ cost function: f(x) = 1/2 x^T M x + q^T x
#   (a) grad f(x) = ?
#   (b) f is convex because ...
#   (c) grad f is L-Lipschitz with L = ?
min_eig, max_eig = 0.1, 1
Q, _  = np.linalg.qr(ran.standard_normal((n, n)))
M     = Q @ np.diag(ran.uniform(min_eig, max_eig, n)) @ Q.T
q     = 10 + ran.standard_normal((n, 1))
x_opt = -np.linalg.inv(M) @ q

# ------ step sizes
#   (c) L = lambda_max(M)
L      = max_eig
steps  = [0.1 / L, 1.0 / L, 3.0 / L]
labels = [rf"$\rho = 0.1/L$ (={steps[0]:.3f})",
          rf"$\rho = 1/L$   (={steps[1]:.3f})",
          rf"$\rho = 3/L$   (={steps[2]:.3f})"]

# ------ (f) run GD for each step size:  x(k+1) = x(k) - rho * grad f(x(k))
results = []
for step, label in zip(steps, labels):
    x = [x_0]
    for k in range(simu_time):
        # TODO (f): implement one GD step and append the new iterate to x
        pass
    results.append(x)
    print(f"Done: {label}")

# ------ comparing plot
plt.rc("text", usetex=True)
plt.rc("font", family="serif")
fontsize = 18
time = np.arange(0, simu_time, 1)
plt.figure()
for x, label in zip(results, labels):
    plt.semilogy(time, [np.linalg.norm(x[k] - x_opt) for k in range(simu_time)], label=label)
plt.legend(fontsize=fontsize - 3)
plt.xlabel("Iteration $k$", fontsize=fontsize)
plt.ylabel(r"$\|x(k) - x^\star\|$", fontsize=fontsize)
plt.grid()
plt.tight_layout()
plt.show()
