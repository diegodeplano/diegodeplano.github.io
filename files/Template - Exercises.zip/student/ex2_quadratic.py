#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exercise 2: Proximal gradient on a quadratic objective with affine constraint.
Compares convergence for rho = 0.1/L, 1/L, 3/L.

Constraint: X = {x : Ax = b} with A = I - (1/n)*ones, b = 0
  => X = {x : all components equal}  (consensus / averaging set)
Projection onto X: Pi_X(v) = mean(v) * ones
"""

import numpy as np
from numpy.random import default_rng
import matplotlib.pyplot as plt

ran = default_rng()

# ------ problem data
n         = 10
simu_time = 1000
x_0       = 10 * ran.standard_normal((n, 1))

# ------ cost function: f(x) = 1/2 x^T M x + q^T x,  grad f(x) = Mx + q
min_eig, max_eig = 0.1, 1
Q, _  = np.linalg.qr(ran.standard_normal((n, n)))
M     = Q @ np.diag(ran.uniform(min_eig, max_eig, n)) @ Q.T
q     = 10 + ran.standard_normal((n, 1))

# ------ optimal solution (via KKT: projected onto X, hence all components = scalar c)
A     = np.eye(n) - (1 / n) * np.ones((n, n))
b     = np.zeros((n, 1))
x_opt = (np.linalg.pinv(np.block([[M, A.T], [A, np.zeros((n, n))]]))
         @ np.concatenate([-q, b]))[:n]

# ------ step sizes
#   (c) grad f is L-Lipschitz; discuss convergence of PG
L      = max_eig
steps  = [0.1 / L, 1.0 / L, 3.0 / L]
labels = [rf"$\rho = 0.1/L$ (={steps[0]:.3f})",
          rf"$\rho = 1/L$   (={steps[1]:.3f})",
          rf"$\rho = 3/L$   (={steps[2]:.3f})"]

# ------ (b) proximal gradient (FBS): x(k+1) = Pi_X(x(k) - rho * grad f(x(k)))
#        Pi_X(v) = mean(v) * ones  (projection onto consensus set)
def proj(v):
    # TODO (b): implement the projection onto X = {x : all components equal}
    pass

results = []
for step, label in zip(steps, labels):
    x = [x_0]
    for k in range(simu_time):
        # TODO (d): implement one FBS step (gradient step + projection) and append to x
        pass
    results.append(x)
    print(f"Done: {label}")

# ------ comparing plot
plt.rc("text", usetex=True)
plt.rc("font", family="serif")
fontsize = 18
time = np.arange(0, simu_time, 1)
plt.figure()
for x, label in zip(results, labels):
    plt.semilogy(time, [np.linalg.norm(x[k] - x_opt) for k in range(simu_time)], label=label)
plt.legend(fontsize=fontsize - 3)
plt.xlabel("Iteration $k$", fontsize=fontsize)
plt.ylabel(r"$\|x(k) - x^\star\|$", fontsize=fontsize)
plt.grid()
plt.tight_layout()
plt.show()
